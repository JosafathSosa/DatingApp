import * as i0 from '@angular/core';
import { Injectable, Component } from '@angular/core';
import { onLCP, onCLS, onFCP, onTTFB, onINP } from 'web-vitals';
import { MeterProvider, PeriodicExportingMetricReader } from '@opentelemetry/sdk-metrics';
import { OTLPMetricExporter } from '@opentelemetry/exporter-metrics-otlp-http';
import { Resource } from '@opentelemetry/resources';
import { tap, catchError } from 'rxjs/operators';
import * as i1 from '@angular/common/http';
import { interval } from 'rxjs';

class NgxMetricsWebService {
    constructor() { }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: NgxMetricsWebService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: NgxMetricsWebService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: NgxMetricsWebService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class NgxMetricsWebComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: NgxMetricsWebComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.9", type: NgxMetricsWebComponent, isStandalone: true, selector: "metrics-ngx-metrics-web", ngImport: i0, template: `
    <p>
      ngx-metrics-web works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: NgxMetricsWebComponent, decorators: [{
            type: Component,
            args: [{ selector: 'metrics-ngx-metrics-web', standalone: true, imports: [], template: `
    <p>
      ngx-metrics-web works!
    </p>
  ` }]
        }] });

class MetricsOtelService {
    metricExporter;
    meterProvider;
    meter;
    constructor() {
        // Configuración de OpenTelemetry para exportar a OpenTelemetry Collector
        this.metricExporter = new OTLPMetricExporter({
            url: 'http://localhost:4318/v1/metrics', // URL del OpenTelemetry Collector
        });
        // Proveedor de métricas con el exportador configurado
        this.meterProvider = new MeterProvider({
            resource: new Resource({
                'service.name': 'angular-app', // Nombre del servicio
            }),
            readers: [
                new PeriodicExportingMetricReader({
                    exporter: this.metricExporter,
                    exportIntervalMillis: 1000, // Intervalo de exportación (1s)
                }),
            ],
        });
        // Definir el medidor (meter)
        this.meter = this.meterProvider.getMeter('angular-app');
    }
    getMeter() {
        return this.meter;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: MetricsOtelService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: MetricsOtelService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: MetricsOtelService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

// Importación de Angular y de la biblioteca web-vitals
class WebVitalsService {
    metricsService;
    lcpHistogram; // Histograma para LCP
    clsHistogram; // Histograma para CLS
    fcpHistogram; // Histograma para FCP
    ttfbHistogram; // Histograma para TTFB
    inpHistogram; // Histograma para INP
    /**
     * Inicializa el servicio de métricas y crea histogramas para cada métrica de Web Vitals.
     * @param metricsService - Servicio de métricas de OpenTelemetry (MetricsOtelService)
     */
    constructor(metricsService) {
        this.metricsService = metricsService;
        const meter = metricsService.getMeter();
        // Crear histogramas para almacenar las métricas de Web Vitals
        this.lcpHistogram = meter.createHistogram('lcp', {
            description: 'Largest Contentful Paint',
        });
        this.clsHistogram = meter.createHistogram('cls', {
            description: 'Cumulative Layout Shift',
        });
        this.fcpHistogram = meter.createHistogram('fcp', {
            description: 'First Contentful Paint',
        });
        this.ttfbHistogram = meter.createHistogram('ttfb', {
            description: 'Time to First Byte',
        });
        this.inpHistogram = meter.createHistogram('inp', {
            description: 'Interaction to Next Paint',
        });
    }
    /**
     * Inicia la recopilación de métricas Web Vitals, registrando los valores en los histogramas.
     */
    startWebVitalsCollection() {
        // Configura el evento para registrar la métrica de LCP (Largest Contentful Paint)
        onLCP((metric) => {
            this.lcpHistogram.record(metric.value, {
                name: metric.name, // Nombre de la métrica
                rating: metric.rating, // Clasificación de la métrica
            });
        });
        // Configura el evento para registrar la métrica de CLS (Cumulative Layout Shift)
        onCLS((metric) => {
            this.clsHistogram.record(metric.value, {
                name: metric.name,
                rating: metric.rating,
            });
        });
        // Configura el evento para registrar la métrica de FCP (First Contentful Paint)
        onFCP((metric) => {
            this.fcpHistogram.record(metric.value, {
                name: metric.name,
                rating: metric.rating,
            });
        });
        // Configura el evento para registrar la métrica de TTFB (Time to First Byte)
        onTTFB((metric) => {
            this.ttfbHistogram.record(metric.value, {
                name: metric.name,
                rating: metric.rating,
            });
        });
        // Configura el evento para registrar la métrica de INP (Interaction to Next Paint)
        onINP((metric) => {
            this.inpHistogram.record(metric.value, {
                name: metric.name,
                rating: metric.rating,
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: WebVitalsService, deps: [{ token: MetricsOtelService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: WebVitalsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: WebVitalsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: MetricsOtelService }] });

class CustomErrorHandlerService {
    metricsService;
    errorCounter;
    warningCounter;
    constructor(metricsService) {
        this.metricsService = metricsService;
        // Crea contadores para errores y advertencias utilizando el `meter` de MetricsOtelService
        const meter = this.metricsService.getMeter();
        // Contador de errores que se incrementa cada vez que ocurre un error en la aplicación
        this.errorCounter = meter.createCounter('error_count', {
            description: 'Número de errores en la aplicación',
        });
        // Contador de advertencias que se incrementa cada vez que ocurre una advertencia en la aplicación
        this.warningCounter = meter.createCounter('warning_count', {
            description: 'Número de advertencias en la aplicación',
        });
        // Sobrescribe el comportamiento predeterminado de `console.warn` para capturar advertencias personalizadas
        this.overrideConsoleWarn();
    }
    /**
     * Maneja los errores incrementando la métrica de errores y registrándolos en la consola.
     * @param error - Error que será manejado
     */
    handleError(error) {
        // Incrementa la métrica de error con el nombre del error o "UnknownError" si no está definido
        this.errorCounter.add(1, { error: error.name || 'UnknownError' });
        // Registra el error en la consola
        console.error('Se ha producido un error:', error);
    }
    /**
     * Maneja advertencias incrementando la métrica de advertencias y registrándolas en la consola.
     * @param warning - Advertencia que será manejada
     */
    handleWarning(warning) {
        // Incrementa la métrica de advertencia con el mensaje de advertencia o "UnknownWarning" si no está definido
        this.warningCounter.add(1, {
            warning: warning.message || 'UnknownWarning',
        });
        // Registra la advertencia en la consola
        console.warn('Advertencia detectada:', warning);
    }
    /**
     * Sobrescribe el comportamiento de `console.warn` para capturar advertencias y procesarlas
     * a través de `handleWarning`, además de permitir la ejecución del comportamiento original.
     */
    overrideConsoleWarn() {
        const originalWarn = console.warn; // Guarda el comportamiento original de `console.warn`
        const customHandler = this;
        console.warn = function (...args) {
            // Envía el warning al manejador personalizado
            customHandler.handleWarning({ message: args[0] });
            // Ejecuta el comportamiento original de `console.warn`
            originalWarn.apply(console, args);
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CustomErrorHandlerService, deps: [{ token: MetricsOtelService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CustomErrorHandlerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: CustomErrorHandlerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: MetricsOtelService }] });

// http-metrics.service.ts
class HttpMetricsService {
    http;
    metricsService;
    requestHistogram;
    requestCounter;
    constructor(http, metricsService) {
        this.http = http;
        this.metricsService = metricsService;
        const meter = this.metricsService.getMeter();
        // Define un histograma para medir la duración de las solicitudes HTTP en segundos
        this.requestHistogram = meter.createHistogram('http_request_duration_seconds', {
            description: 'Mide la duración de las solicitudes HTTP en segundos',
        });
        // Define un contador para registrar el número de solicitudes HTTP agrupadas por estado
        this.requestCounter = meter.createCounter('http_request_status_count', {
            description: 'Cuenta el número de solicitudes HTTP por código de estado',
        });
    }
    /**
     * Realiza una solicitud HTTP GET y registra métricas de duración y estado.
     * @param url - URL de destino de la solicitud GET
     * @returns Observable con el tipo de respuesta esperado
     */
    get(url) {
        const startTime = performance.now(); // Marca el inicio de la solicitud
        return this.http
            .get(url, { headers: { 'Cache-Control': 'no-cache' } })
            .pipe(tap(() => {
            const endTime = performance.now(); // Marca el fin de la solicitud
            const duration = (endTime - startTime) / 1000; // Duración en segundos
            // Registra la duración de la solicitud en el histograma
            this.requestHistogram.record(duration, {
                method: 'GET',
                status: '200',
                url,
            });
            // Incrementa el contador para solicitudes exitosas (código 200)
            this.requestCounter.add(1, { method: 'GET', status: '200', url });
        }), catchError((error) => {
            // Captura y maneja errores, registrando el código de estado si existe
            const statusCode = error.status || 'unknown';
            this.requestCounter.add(1, {
                method: 'GET',
                status: statusCode.toString(),
                url,
            });
            throw error; // Lanza el error para su manejo externo
        }));
    }
    /**
     * Realiza una solicitud HTTP POST y registra métricas de duración y estado.
     * @param url - URL de destino de la solicitud POST
     * @param body - Cuerpo de la solicitud POST
     * @returns Observable con el tipo de respuesta esperado
     */
    post(url, body) {
        const startTime = performance.now(); // Marca el inicio de la solicitud
        return this.http.post(url, body).pipe(tap(() => {
            const endTime = performance.now(); // Marca el fin de la solicitud
            const duration = (endTime - startTime) / 1000; // Duración en segundos
            // Registra la duración de la solicitud en el histograma
            this.requestHistogram.record(duration, {
                method: 'POST',
                status: '200',
                url,
            });
            // Incrementa el contador para solicitudes exitosas (código 200)
            this.requestCounter.add(1, { method: 'POST', status: '200', url });
        }), catchError((error) => {
            // Captura y maneja errores, registrando el código de estado si existe
            const statusCode = error.status || 'unknown';
            this.requestCounter.add(1, {
                method: 'POST',
                status: statusCode.toString(),
                url,
            });
            throw error; // Lanza el error para su manejo externo
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: HttpMetricsService, deps: [{ token: i1.HttpClient }, { token: MetricsOtelService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: HttpMetricsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: HttpMetricsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: MetricsOtelService }] });

// component-metrics.service.ts
class ComponentMetricsService {
    metricsService;
    meter;
    visitCounter;
    renderTimeHistogram;
    memoryUsageHistogram;
    sessionDurationHistogram;
    // Variables internas para seguimiento de tiempo
    sessionStartTime;
    renderStartTime;
    constructor(metricsService) {
        this.metricsService = metricsService;
        this.meter = this.metricsService.getMeter();
    }
    /**
    * Configura un contador de visitas para la página o componente actual.
    * Este contador registra la cantidad de veces que la página o componente ha sido visitado.
    * @param name - Nombre del contador (predeterminado: 'page_visit_counter')
    * @param description - Descripción del contador
    */
    configureVisitCounter(name = 'page_visit_counter', description = 'Number of page visits') {
        this.visitCounter = this.meter.createCounter(name, { description });
    }
    /**
    * Incrementa el contador de visitas en uno para un componente específico.
    * @param componentName - Nombre del componente que se está visitando
    */
    trackVisit(componentName) {
        if (this.visitCounter) {
            this.visitCounter.add(1, { page: componentName });
        }
        else {
            console.warn('Visit counter not configured.');
        }
    }
    /**
    * Inicia el tiempo de la sesión del usuario, usando `performance.now()` para obtener la marca de tiempo inicial.
    */
    startSession() {
        this.sessionStartTime = performance.now();
    }
    /**
     * Finaliza la sesión y registra su duración en el histograma correspondiente.
     * @param name - Nombre del histograma de duración de la sesión
     * @param description - Descripción del histograma
     */
    endSession(name = 'session_duration_histogram', description = 'Duration of user session') {
        if (!this.sessionStartTime) {
            console.warn('Session has not been started.');
            return;
        }
        const sessionDuration = (performance.now() - this.sessionStartTime) / 1000; // Convertir a segundos
        this.configureSessionDurationHistogram(name, description, 's');
        this.trackSessionDuration(sessionDuration);
    }
    // Inicia el seguimiento del tiempo de renderizado
    startRender() {
        this.renderStartTime = performance.now();
    }
    /**
    * Finaliza el tiempo de renderizado y registra el tiempo en el histograma de renderizado.
    * @param name - Nombre del histograma de tiempo de renderizado
    * @param description - Descripción del histograma
    */
    endRender(name = 'render_time_histogram', description = 'Render time of component') {
        if (!this.renderStartTime) {
            console.warn('Render time has not been started.');
            return;
        }
        const renderTime = performance.now() - this.renderStartTime; // Tiempo en milisegundos
        this.configureRenderTimeHistogram(name, description, 'ms');
        this.trackRenderTime(renderTime);
    }
    /**
    * Configura un histograma para registrar el tiempo de renderizado de un componente.
    * @param name - Nombre del histograma
    * @param description - Descripción del histograma
    * @param unit - Unidad de tiempo (e.g., 'ms' para milisegundos)
    */
    configureRenderTimeHistogram(name, description, unit) {
        this.renderTimeHistogram = this.meter.createHistogram(name, {
            description,
            unit,
        });
    }
    /**
   * Registra el tiempo de renderizado en el histograma configurado.
   * @param duration - Duración en ms del tiempo de renderizado
   */
    trackRenderTime(duration) {
        if (this.renderTimeHistogram) {
            this.renderTimeHistogram.record(duration, {
                component: 'current-component',
            });
        }
        else {
            console.warn('Render time histogram not configured.');
        }
    }
    /**
    * Configura un histograma para registrar la duración de una sesión de usuario.
    * @param name - Nombre del histograma
    * @param description - Descripción del histograma
    * @param unit - Unidad de tiempo (e.g., 's' para segundos)
    */
    configureSessionDurationHistogram(name, description, unit) {
        this.sessionDurationHistogram = this.meter.createHistogram(name, {
            description,
            unit,
        });
    }
    trackSessionDuration(duration) {
        if (this.sessionDurationHistogram) {
            this.sessionDurationHistogram.record(duration, { user: 'current-user' });
        }
        else {
            console.warn('Session duration histogram not configured.');
        }
    }
    /**
    * Registra la duración de una sesión en el histograma configurado.
    * @param duration - Duración de la sesión en segundos
    */
    configureMemoryUsage(name = 'memory_usage_histogram', description = 'Memory usage of component in MB') {
        this.memoryUsageHistogram = this.meter.createHistogram(name, {
            description,
            unit: 'MB',
        });
    }
    /**
   * Configura un histograma para registrar el uso de memoria de un componente.
   * @param name - Nombre del histograma (predeterminado: 'memory_usage_histogram')
   * @param description - Descripción del histograma
   */
    trackMemoryUsage() {
        if (this.memoryUsageHistogram) {
            const memoryUsage = this.getCurrentMemoryUsage();
            this.memoryUsageHistogram.record(memoryUsage, {
                component: 'current-component',
            });
        }
        else {
            console.warn('Memory usage histogram not configured.');
        }
    }
    /**
     * Registra el uso de memoria actual en el histograma configurado.
     */
    getCurrentMemoryUsage() {
        if (performance && performance.memory) {
            return performance.memory.usedJSHeapSize / 1024 / 1024; // Convertir a MB
        }
        return 0;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: ComponentMetricsService, deps: [{ token: MetricsOtelService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: ComponentMetricsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: ComponentMetricsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: MetricsOtelService }] });

class DependencyIssuesService {
    metricsService;
    meter;
    constructor(metricsService) {
        this.metricsService = metricsService;
        this.meter = metricsService.getMeter();
    }
    /**
     * Verifica y maneja las dependencias en el componente.
     * Envía métricas de error si faltan dependencias y retorna los problemas encontrados.
     *
     * @param component Instancia del componente donde se esperan las dependencias.
     * @param metricName Nombre de la métrica a registrar.
     * @param metricDescription Descripción de la métrica para identificarla en Prometheus.
     * @returns Array de strings con problemas encontrados, si existen.
     */
    verifyAndHandleDependencies(component, metricName = 'dependency_issues', description = 'Número de problemas detectados en dependencias') {
        const issues = [];
        const dependencyIssuesCounter = this.meter.createCounter(metricName, {
            description,
        });
        // Verificar si las dependencias de Web Vitals están presentes en el componente
        if (!component.onLCP) {
            issues.push('onLCP no está importado ni utilizado en el componente');
        }
        if (!component.onINP) {
            issues.push('onINP no está importado ni utilizado en el componente');
        }
        if (!component.onCLS) {
            issues.push('onCLS no está importado ni utilizado en el componente');
        }
        if (!component.onTTFB) {
            issues.push('onTTFB no está importado ni utilizado en el componente');
        }
        if (!component.onFCP) {
            issues.push('onFCP no está importado ni utilizado en el componente');
        }
        issues.forEach((issue) => {
            console.error('Problema detectado:', issue);
            dependencyIssuesCounter.add(1, { issue });
        });
        return issues;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: DependencyIssuesService, deps: [{ token: MetricsOtelService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: DependencyIssuesService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: DependencyIssuesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: MetricsOtelService }] });

class AppStatusService {
    metricsService;
    appStatusGauge;
    appStatusSubscription;
    constructor(metricsService) {
        this.metricsService = metricsService;
        window.addEventListener('beforeunload', this.handleBeforeUnload);
    }
    /**
     * Inicia el seguimiento del estado activo de la aplicación y envía una métrica periódica.
     *
     * @param metricName
     * @param metricDescription
     */
    startTrackingStatus(metricName, metricDescription) {
        const meter = this.metricsService.getMeter();
        this.appStatusGauge = meter.createObservableGauge(metricName, {
            description: metricDescription,
        });
        this.appStatusGauge.addCallback((observableResult) => {
            observableResult.observe(1);
        });
        this.appStatusSubscription = interval(15000).subscribe(() => {
            console.log(`Aplicación activa, enviando métrica de estado "${metricName}".`);
        });
    }
    handleBeforeUnload = (event) => {
        console.log('Enviando métrica de estado 0 antes de cerrar o recargar.');
        if (this.appStatusGauge) {
            this.appStatusGauge.addCallback((observableResult) => {
                observableResult.observe(0);
            });
        }
        event.preventDefault();
        event.returnValue = '';
    };
    ngOnDestroy() {
        if (this.appStatusSubscription) {
            this.appStatusSubscription.unsubscribe();
        }
        window.removeEventListener('beforeunload', this.handleBeforeUnload);
        console.log('AppStatusService destruido y recursos liberados');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AppStatusService, deps: [{ token: MetricsOtelService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AppStatusService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.9", ngImport: i0, type: AppStatusService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: MetricsOtelService }] });

/*
 * Public API Surface of ngx-metrics-web
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AppStatusService, ComponentMetricsService, CustomErrorHandlerService, DependencyIssuesService, HttpMetricsService, NgxMetricsWebComponent, NgxMetricsWebService, WebVitalsService };
//# sourceMappingURL=ngx-metrics-web.mjs.map
