/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-metrics-web" />
export * from './public-api';
