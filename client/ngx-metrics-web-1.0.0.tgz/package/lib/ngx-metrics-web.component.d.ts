import * as i0 from "@angular/core";
export declare class NgxMetricsWebComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxMetricsWebComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxMetricsWebComponent, "metrics-ngx-metrics-web", never, {}, {}, never, never, true, never>;
}
