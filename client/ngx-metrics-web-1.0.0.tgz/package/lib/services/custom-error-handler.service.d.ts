import { ErrorHandler } from '@angular/core';
import { MetricsOtelService } from './metrics-otel.service';
import * as i0 from "@angular/core";
export declare class CustomErrorHandlerService implements ErrorHandler {
    private metricsService;
    private errorCounter;
    private warningCounter;
    constructor(metricsService: MetricsOtelService);
    /**
     * Maneja los errores incrementando la métrica de errores y registrándolos en la consola.
     * @param error - Error que será manejado
     */
    handleError(error: any): void;
    /**
     * Maneja advertencias incrementando la métrica de advertencias y registrándolas en la consola.
     * @param warning - Advertencia que será manejada
     */
    handleWarning(warning: any): void;
    /**
     * Sobrescribe el comportamiento de `console.warn` para capturar advertencias y procesarlas
     * a través de `handleWarning`, además de permitir la ejecución del comportamiento original.
     */
    private overrideConsoleWarn;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomErrorHandlerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomErrorHandlerService>;
}
