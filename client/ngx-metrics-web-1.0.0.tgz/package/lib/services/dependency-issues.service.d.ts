import { MetricsOtelService } from './metrics-otel.service';
import * as i0 from "@angular/core";
export declare class DependencyIssuesService {
    private metricsService;
    private meter;
    constructor(metricsService: MetricsOtelService);
    /**
     * Verifica y maneja las dependencias en el componente.
     * Envía métricas de error si faltan dependencias y retorna los problemas encontrados.
     *
     * @param component Instancia del componente donde se esperan las dependencias.
     * @param metricName Nombre de la métrica a registrar.
     * @param metricDescription Descripción de la métrica para identificarla en Prometheus.
     * @returns Array de strings con problemas encontrados, si existen.
     */
    verifyAndHandleDependencies(component: any, metricName?: string, description?: string): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<DependencyIssuesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DependencyIssuesService>;
}
