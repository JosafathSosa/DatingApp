import { MetricsOtelService } from './metrics-otel.service';
import * as i0 from "@angular/core";
export declare class ComponentMetricsService {
    private metricsService;
    private meter;
    private visitCounter;
    private renderTimeHistogram;
    private memoryUsageHistogram;
    private sessionDurationHistogram;
    private sessionStartTime;
    private renderStartTime;
    constructor(metricsService: MetricsOtelService);
    /**
    * Configura un contador de visitas para la página o componente actual.
    * Este contador registra la cantidad de veces que la página o componente ha sido visitado.
    * @param name - Nombre del contador (predeterminado: 'page_visit_counter')
    * @param description - Descripción del contador
    */
    configureVisitCounter(name?: string, description?: string): void;
    /**
    * Incrementa el contador de visitas en uno para un componente específico.
    * @param componentName - Nombre del componente que se está visitando
    */
    trackVisit(componentName: string): void;
    /**
    * Inicia el tiempo de la sesión del usuario, usando `performance.now()` para obtener la marca de tiempo inicial.
    */
    startSession(): void;
    /**
     * Finaliza la sesión y registra su duración en el histograma correspondiente.
     * @param name - Nombre del histograma de duración de la sesión
     * @param description - Descripción del histograma
     */
    endSession(name?: string, description?: string): void;
    startRender(): void;
    /**
    * Finaliza el tiempo de renderizado y registra el tiempo en el histograma de renderizado.
    * @param name - Nombre del histograma de tiempo de renderizado
    * @param description - Descripción del histograma
    */
    endRender(name?: string, description?: string): void;
    /**
    * Configura un histograma para registrar el tiempo de renderizado de un componente.
    * @param name - Nombre del histograma
    * @param description - Descripción del histograma
    * @param unit - Unidad de tiempo (e.g., 'ms' para milisegundos)
    */
    configureRenderTimeHistogram(name: string, description: string, unit: string): void;
    /**
   * Registra el tiempo de renderizado en el histograma configurado.
   * @param duration - Duración en ms del tiempo de renderizado
   */
    trackRenderTime(duration: number): void;
    /**
    * Configura un histograma para registrar la duración de una sesión de usuario.
    * @param name - Nombre del histograma
    * @param description - Descripción del histograma
    * @param unit - Unidad de tiempo (e.g., 's' para segundos)
    */
    configureSessionDurationHistogram(name: string, description: string, unit: string): void;
    trackSessionDuration(duration: number): void;
    /**
    * Registra la duración de una sesión en el histograma configurado.
    * @param duration - Duración de la sesión en segundos
    */
    configureMemoryUsage(name?: string, description?: string): void;
    /**
   * Configura un histograma para registrar el uso de memoria de un componente.
   * @param name - Nombre del histograma (predeterminado: 'memory_usage_histogram')
   * @param description - Descripción del histograma
   */
    trackMemoryUsage(): void;
    /**
     * Registra el uso de memoria actual en el histograma configurado.
     */
    private getCurrentMemoryUsage;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentMetricsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ComponentMetricsService>;
}
