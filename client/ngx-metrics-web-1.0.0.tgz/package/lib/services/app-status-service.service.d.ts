import { OnDestroy } from '@angular/core';
import { MetricsOtelService } from './metrics-otel.service';
import * as i0 from "@angular/core";
export declare class AppStatusService implements OnDestroy {
    private metricsService;
    private appStatusGauge;
    private appStatusSubscription;
    constructor(metricsService: MetricsOtelService);
    /**
     * Inicia el seguimiento del estado activo de la aplicación y envía una métrica periódica.
     *
     * @param metricName
     * @param metricDescription
     */
    startTrackingStatus(metricName: string, metricDescription: string): void;
    private handleBeforeUnload;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AppStatusService>;
}
