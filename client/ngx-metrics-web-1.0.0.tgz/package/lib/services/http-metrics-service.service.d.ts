import { HttpClient } from '@angular/common/http';
import { MetricsOtelService } from './metrics-otel.service';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class HttpMetricsService {
    private http;
    private metricsService;
    private requestHistogram;
    private requestCounter;
    constructor(http: HttpClient, metricsService: MetricsOtelService);
    /**
     * Realiza una solicitud HTTP GET y registra métricas de duración y estado.
     * @param url - URL de destino de la solicitud GET
     * @returns Observable con el tipo de respuesta esperado
     */
    get<T>(url: string): Observable<T>;
    /**
     * Realiza una solicitud HTTP POST y registra métricas de duración y estado.
     * @param url - URL de destino de la solicitud POST
     * @param body - Cuerpo de la solicitud POST
     * @returns Observable con el tipo de respuesta esperado
     */
    post<T>(url: string, body: any): Observable<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpMetricsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HttpMetricsService>;
}
