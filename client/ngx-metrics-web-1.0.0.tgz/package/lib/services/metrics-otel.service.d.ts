import * as i0 from "@angular/core";
export declare class MetricsOtelService {
    private metricExporter;
    private meterProvider;
    private meter;
    constructor();
    getMeter(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MetricsOtelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MetricsOtelService>;
}
