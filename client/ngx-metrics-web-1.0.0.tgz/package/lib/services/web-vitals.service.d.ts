import { MetricsOtelService } from './metrics-otel.service';
import * as i0 from "@angular/core";
export declare class WebVitalsService {
    private metricsService;
    private lcpHistogram;
    private clsHistogram;
    private fcpHistogram;
    private ttfbHistogram;
    private inpHistogram;
    /**
     * Inicializa el servicio de métricas y crea histogramas para cada métrica de Web Vitals.
     * @param metricsService - Servicio de métricas de OpenTelemetry (MetricsOtelService)
     */
    constructor(metricsService: MetricsOtelService);
    /**
     * Inicia la recopilación de métricas Web Vitals, registrando los valores en los histogramas.
     */
    startWebVitalsCollection(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WebVitalsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WebVitalsService>;
}
