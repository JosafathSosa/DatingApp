import * as i0 from "@angular/core";
export declare class NgxMetricsWebService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxMetricsWebService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NgxMetricsWebService>;
}
